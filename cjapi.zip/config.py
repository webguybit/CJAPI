import os

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
PORT = 5559
HOST = 'http://127.0.0.1'
BASE_URL = '{}:{}'.format(HOST,PORT)